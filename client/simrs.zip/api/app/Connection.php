<?php

namespace PondokCoder;

class Connection {
	private static $conn;
	public function connect() {
		$params = parse_ini_file('database.ini');

		//PostgreSQL
		//==================================================================
		$conStr = sprintf("pgsql:host=%s;port=%d;dbname=%s;user=%s;password=%s",
			$params['host'],
			$params['port'],
			$params['database'],
			$params['user'],
			$params['password']);
		$pdo = new \PDO($conStr);



		//MySQL
		//==================================================================
		/*$conStr = sprintf("mysql:host=%s;dbname=%s",
			$params['host'],
			$params['database']);*/

		//$pdo = new \PDO($conStr, $params['user'], $params['password']);
		




		$pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

		return $pdo;
	}
	public static function get() {
		if (null === static::$conn) {
			static::$conn = new static();
		}

		return static::$conn;
	}

	protected function __construct() {
		
	}

	private function __clone() {

	}

	private function __wakeup() {

	}

}
?>