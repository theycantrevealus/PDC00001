<div class="card-group">
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-2">
				<i class="material-icons icon-muted icon-30pt">account_circle</i>
			</div>
			<div class="col-md-10">
				<b>101-02-11</b><br />
				<span>JOHN DOE</span>
				<br />
				<span>Laki-laki</span>
				<br />
				<span>10 Januari 1989</span>
			</div>
		</div>
	</div>
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-12">
				<table class="table table-bordered">
					<tr>
						<td>
							Dokter
						</td>
						<td>
							Dr. John Doe
						</td>
					</tr>
					<tr>
						<td>
							Jam Triase
						</td>
						<td>
							Dr. John Doe
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>