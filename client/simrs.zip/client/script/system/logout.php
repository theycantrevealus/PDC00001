<script type="text/javascript">
	location.href = __HOSTNAME__;
</script>