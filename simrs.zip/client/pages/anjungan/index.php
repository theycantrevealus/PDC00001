<div class="anjungan-container">
	<div class="container-fluid page__container" style="margin-top: 100px;">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<div class="card">
					<div class="card-body">
						<select id="anjungan_selection" class="form-control">
							
						</select>
						<center>
							<table>
								<tr>
									<td>
										<img width="120" height="100" src="<?php echo __HOSTNAME__; ?>/template/assets/images/logo.png" />			
									</td>
									<td>
										<h3>RUMAH SAKIT UMUM DAERAH PETALA BUMI</h3>
										<i class="fa fa-map-marker" style="color: red;"></i> Jalan Dr. Soetomo No. 65, Sekip, LimaPuluh, Kota Pekanbaru, Riau 28155. Telp. (0761)23024
									</td>
								</tr>
							</table>
						</center>
						<div style="margin-top: 20px">
							<div class="px-3">
								<div class="d-flex justify-content-center flex-column text-center my-5 navbar-light">
									<div class="row" id="loader-jenis">
									</div>
									<!-- <button class="btn btn-info btn-lg" style="height: 100px;">
										<h1 style="color: #fff">AMBIL ANTRIAN</h1>
									</button> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>