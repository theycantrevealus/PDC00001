<?php require 'form-header.php'; ?>
<div class="row">
	<div class="col-lg">
		<div class="card">
			<div class="card-header card-header-large bg-white d-flex align-items-center">
				<h5 class="card-header__title flex m-0">Lokasi Penyimpanan</h5>
			</div>
			<div class="card-body tab-content">
				<table class="table table-bordered" id="table-lokasi-gudang">
					<thead>
						<tr>
							<th style="width: 10%;" class="wrap_content">No</th>
							<th>Gudang</th>
							<th>No Rak</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>