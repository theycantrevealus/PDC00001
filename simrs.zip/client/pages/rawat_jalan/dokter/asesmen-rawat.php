<div class="col-md-12">
	<div class="z-0">
		<ul class="nav nav-tabs nav-tabs-custom" role="tablist">
			<li class="nav-item">
				<a href="#tab-rawat-1" class="nav-link active" data-toggle="tab" role="tab" aria-selected="true" aria-controls="tab-rawat-1" >
					<span class="nav-link__count">
						01
						<b class="inv-tab-status text-success" id="rawat-1"><i class="fa fa-check-circle"></i></b>
					</span>
					Halaman
				</a>
			</li>
			<li class="nav-item">
				<a href="#tab-rawat-2" class="nav-link" data-toggle="tab" role="tab" aria-selected="false">
					<span class="nav-link__count">
						02
						<b class="inv-tab-status text-success" id="rawat-2"><i class="fa fa-check-circle"></i></b>
					</span>
					Halaman
				</a>
			</li>
		</ul>
	</div>
	<div class="tab-content">
		<div class="tab-pane active show fade" id="tab-rawat-1">
			
		</div>
		<div class="tab-pane show fade" id="tab-rawat-2">

		</div>
	</div>
</div>