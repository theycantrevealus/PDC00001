<div class="card-group">
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-2">
				<i class="material-icons icon-muted icon-30pt">account_circle</i>
			</div>
			<div class="col-md-10">
				<b class="nama_pasien"></b>
				<br />
				<span class="jk_pasien"></span>
				<br />
				<span class="tanggal_lahir_pasien"></span>
			</div>
		</div>
	</div>
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-12">
				<b>Penjamin</b>
				<h5 class="penjamin_pasien text-success"></h5>
			</div>
		</div>
	</div>
</div>